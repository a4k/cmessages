/** [Dialogs] Routes
	* server page of dialogs page
 */

var express = require('express'),
	router = express.Router(),
	fs = require('fs'),
	moment = require('moment'),
	multiparty = require('multiparty');


var Dialogs = require('../models/dialogs'),
    Documents = require('../models/documents'),
    Photos = require('../models/photos');
var dir = {
    images: './public/uploads/images',
    images2: '/uploads/images/',
    docs: './public/uploads/docs/',
    docs2: '/uploads/docs/',
    photos: './public/uploads/photos/',
    photos2: '/uploads/photos/'
  };

// Dialogs
router.get('/', ensureAuthenticated, function(req, res) {
	user = req.user;
	res.render('dialogs');
});

// Dialog page
router.get('/:did', ensureAuthenticated, function(req, res) {
	user = req.user;
	res.render('dialogPage');
});


// upload files
router.post('/', ensureAuthenticated, function(req, res) {
	// create form
    var form = new multiparty.Form(), // file path, type and his size
    	uploadFile = {uploadPath: '', type: '', size: 0}, // max file size
    	maxSize = 15 * 1024 * 1024, // 15 MB // accept types
    	supportImageTypes = ['image/jpg', 'image/jpeg', 'image/png',
    	'image/gif',
    	'image/bmp',

    	], // array of image types
    	supportDocTypes = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    	'application/vnd.openxmlformats-officedocument.spreadsheetml.template',
    	'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    	'application/vnd.openxmlformats-officedocument.presentationml.template',
    	'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
    	'application/vnd.openxmlformats-officedocument.presentationml.slide',
    	'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    	'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
    	'application/vnd.ms-powerpoint',
    	'application/x-mspublisher',
    	'application/msword',
    	'application/x-rar-compressed',
    	'application/x-font-linux-psf',
    	'application/rtf',
    	'image/svg+xml',
    	'application/x-font-ttf',
    	'text/plain',
    	'application/zip',
    	'application/x-7z-compressed',
    	'image/vnd.adobe.photoshop',
    	], // array of document types
    	errors = [], linkToFile, currentDate = moment().unix(), filename, photoFileName, direct, size;

     // check error
    form.on('error', function(err){
        /*if(fs.existsSync(uploadFile.path)) {
            // delete this file
            fs.unlinkSync(uploadFile.path);
            console.log('error');
        }*/
    });

    form.on('close', function() {
        // all good
        if(errors.length == 0) {
            // no errors
            res.send({status: 'ok', info: [linkToFile, currentDate, photoFileName, direct, filename, size]});
        }
        else {
            /*if(fs.existsSync(uploadFile.path)) {
                //delete this file
                fs.unlinkSync(uploadFile.path);
            }*/
            // have errors
            res.send({status: 'bad', errors: errors});
        }
    });

    // file appear
    form.on('part', function(part) {
        // read size
        uploadFile.size = part.byteCount;
        //read type
        uploadFile.type = part.headers['content-type'];
        // file path is exist
        if(checkYet(part.filename)) {
        	filename = part.filename;
            let filename2 = '.' + filename.split('.').pop(-1);
        	size = part.byteCount;
			photoFileName = Math.random() * (999 - 111) + 111 + filename2;
        	if(supportDocTypes.indexOf(uploadFile.type) > -1) {
        		// its document
				linkToFile = dir.docs2 + currentDate + photoFileName;
				uploadFile.path = dir.docs + currentDate + photoFileName;
				direct = 'docs';
        		
        	}
        	else if(supportImageTypes.indexOf(uploadFile.type) > -1) {
        		// its photo
				linkToFile = dir.photos2 + currentDate + photoFileName;
				uploadFile.path = dir.photos + currentDate + photoFileName;
				direct = 'photos';
        		
        	} else {
        		// its bad file
        		errors.push('Unsupported mimetype ' + uploadFile.type);
        	}

			// check file size
			if(uploadFile.size > maxSize) {
			  errors.push('File size is ' + uploadFile.size + '. Limit is' + (maxSize / 1024 / 1024) + 'MB.');
			}

			/* // if accept type
			if(supportMimeTypes.indexOf(uploadFile.type) == -1) {
			  errors.push('Unsupported mimetype ' + uploadFile.type);
			}*/

			// no errors make flow
			if(errors.length == 0) {
                let out = fs.createWriteStream(uploadFile.path);
                part.pipe(out);
                
			}
			else {
			  // miss
			  // stop upload on go to close
			  part.resume();
			}
        } else {
        	part.resume();
        }
        
      
    });

    // парсим форму
    form.parse(req);
})

// check user is logged in
function ensureAuthenticated(req, res, next) {
	if(req.isAuthenticated()) {
		// if user is logged in
		return next();
	} else {
		// user is not logged in
		res.redirect('/')
	}
}

function checkYet(a) {
    if(a === undefined || a === null) {
      return false;
    } else {
      return true;
    }
  }


module.exports = router;