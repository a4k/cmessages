var express = require('express'),
	fs = require('fs'),
	moment = require('moment'),
	router = express.Router();


// Friends
router.get('/', ensureAuthenticated, function(req, res) {
	user = req.user;
	res.render('friends');
});


// check user is logged in
function ensureAuthenticated(req, res, next) {
	if(req.isAuthenticated()) {
		// if user is logged in
		return next();
	} else {
		// user is not logged in
		res.redirect('/')
	}
}

function checkYet(a) {
    if(a === undefined || a === null) {
      return false;
    } else {
      return true;
    }
  }


module.exports = router;