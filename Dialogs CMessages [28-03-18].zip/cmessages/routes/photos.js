var express = require('express');
var router = express.Router();


// Photos
router.get('/photos', function(req, res) {
	res.render('photos');
});

module.exports = router;