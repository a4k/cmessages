var mongoose = require('mongoose');
var bcrypt = require('bcryptjs');


// Dialog schema
var PhotoSchema = mongoose.Schema({
	did: {
		type: Number,
		index: true,
	},
	name: {
		type: String,
	},
	link: {
		type: String,
	},
	username: {
		type: String,
	},
	size: {
		type: String, 
	},
	type: {
		type: String,
	},
	mdate: {
		type: String, // moment date
	}
});

var Photos = module.exports = mongoose.model('Photos', PhotoSchema);

// function create Photo
module.exports.createPhoto = function(newPhoto, callback){
	newPhoto.save(callback);
}

// ged count of Photos
module.exports.getCountOfPhotos = function(query = {}, callback) {
	Photos.count(query, callback);
}

// get photo by did
module.exports.getPhoto = function(did, callback) {
	Photos.findOne({did: did}, callback);
}

// get photos 
module.exports.getPhotos = function(page, query, callback) {
  let photos = [], limit = 10,
      start = (page * limit);
  // Query the db, using skip and limit to achieve page chunks
  Photos.find(query,'did username name link size type mdate',{skip: start, limit: limit}).sort({mdate: -1}).exec(function(err,msg){
    // If everything is cool...
    if(!err) {
      photos = msg;  // We got photos
    }
    photos.reverse();
    // Pass them back to the specified callback
    callback(photos);
  });
};

// find Photo
module.exports.findPhoto = function(query, callback) {
	if(query) {
		Photos.findOne(query, callback);
	}
}
