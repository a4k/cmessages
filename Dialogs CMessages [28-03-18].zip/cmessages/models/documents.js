var mongoose = require('mongoose');
var bcrypt = require('bcryptjs');


// Dialog schema
var DocumentSchema = mongoose.Schema({
	did: {
		type: Number,
		index: true,
	},
	name: {
		type: String,
	},
	link: {
		type: String,
	},
	username: {
		type: String,
	},
	size: {
		type: String, 
	},
	type: {
		type: String,
	},
	mdate: {
		type: String, // moment date
	}
});

var Documents = module.exports = mongoose.model('Documents', DocumentSchema);

// function create Document
module.exports.createDocument = function(newDocument, callback){
	newDocument.save(callback);
}

// ged count of Documents
module.exports.getCountOfDocuments = function(query = {}, callback) {
	Documents.count(query, callback);
}

// get document by did
module.exports.getDocument = function(did, callback) {
	Documents.findOne({did: did}, callback);
}

// get documents 
module.exports.getDocuments = function(page, query, callback) {
  let documents = [], limit = 10,
      start = (page * limit);
  // Query the db, using skip and limit to achieve page chunks
  Documents.find(query,'did username name link size type mdate',{skip: start, limit: limit}).sort({mdate: -1}).exec(function(err,msg){
    // If everything is cool...
    if(!err) {
      documents = msg;  // We got documents
    }
    documents.reverse();
    // Pass them back to the specified callback
    callback(documents);
  });
};

// find Document
module.exports.findDocument = function(query, callback) {
	if(query) {
		Documents.findOne(query, callback);
	}
}
