var mongoose = require('mongoose');
var bcrypt = require('bcryptjs');


// Friend schema
var FriendSchema = mongoose.Schema({
	fid: {
		type: Number,
		index: true,
	},
	fusername: {
		type: String,
	},
	username: {
		type: String,
	},
	list: {
		type: String, // 0 - none, 1 - best friends
	},
	type: {
		type: String,
	},
	mdate: {
		type: String, // moment date
	}
});

var Friends = module.exports = mongoose.model('Friends', FriendSchema);

// function create Friend
module.exports.createFriend = function(newFriend, callback){
	newFriend.save(callback);
}

// ged count of Friends
module.exports.getCountOfFriends = function(query = {}, callback) {
	Friends.count(query, callback);
}

// get Friend by fid
module.exports.getFriend = function(fid, callback) {
	Friends.findOne({fid: fid}, callback);
}

// get Friends 
module.exports.getFriends = function(page, query, callback) {
  let friends = [], limit = 10,
      start = (page * limit);
  // Query the db, using skip and limit to achieve page chunks
  Friends.find(query,'fid username fusername list type mdate',{skip: start, limit: limit}).sort({mdate: -1}).exec(function(err,msg){
    // If everything is cool...
    if(!err) {
      friends = msg;  // We got Friends
    }
    friends.reverse();
    // Pass them back to the specified callback
    callback(friends);
  });
};

// find Friend
module.exports.findFriend = function(query, callback) {
	if(query) {
		Friends.findOne(query, callback);
	}
}
// remove Friend
module.exports.removeFriend = function(query, callback) {
	if(query) {
		Friends.remove(query, callback);
	}
}
