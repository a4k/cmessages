// main.jsx




var $dom, 
$chat = {},
isLogged = false, // user state logged in or no
$username = false,
clear = false,
Drop = {}, // Drop class
socket = io();


//user info
$chat.data = {
	first_name: false, last_name: false, date: false, email: false, username: false, password: false
};

// dialog info
$chat.info = {
	did: false,
	recepient: {
		photo: '', // avatar
		username: '',
		status: '', // online, offline
		name: '',
		last_activity: '',
	},
	dropfiles: new Set(),
};

// search info
$chat.search ={
	info: '',
};

// navigation links
$chat.nav = {
	header_noLogged: [['users/login','Войти'],['users/register','Регистрация']], // if user no logged in
	sidebar: ['home','dialogs','users', 'friends'], // left menu
	header: false, // if user logged in
};


isConsole('Hello Developer. Its just #15 version. Be happy');
isConsole('Im Nikita Brovkovich :: vk.com/a4kosen');

var $socket = io.connect();
var siofu = new SocketIOFileUpload($socket);



// Main page -- Index
class Container extends React.Component {
	render() {
		return (
			<div className="page">
				<div className="header clearfix">
					<div className="container">
						<Header />
					</div>
				</div>
				<div className="container">
					<section className="main">
						<Body page={this.props.page} />
					</section>
				</div>
			</div>
		);
	}
}

// Header
class Header extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			username: false,
		}

		this.didSocketInclude(this);
	}

	didSocketInclude($this) {
		socket.on('connectUser', function(msg) {
			// true connection
			$username = msg;
			$this.setState({
				username: msg,
			})
			$chat.user.state(); // user is active or no
			$chat.user.upload();
		});
	}

	render() {
		// set header menu links
		let $this = this;
		if(this.state.username) {
			$chat.nav.header = [['','Главная'],
				['users/'+$username,'Профиль'],
				['friends','Друзья'],
				['users/logout','Выйти'],
			];
			return (
				<div className="header_row">
					<div className="logo float-left"><a href="/">Чат</a></div>
					<div className="float-right navigation">
						{$chat.nav.header.map((value, index) => {
							return <Link key={index} link={value[0]} label={value[1]} />
						})}
					</div>
				</div>
				);
			
		} else {
			return (
				<div className="header_row">
					<div className="logo float-left"><a href="/">Чат</a></div>
					<div className="float-right navigation">
						{$chat.nav.header_noLogged.map((value, index) => {
							return <Link key={index} link={value[0]} label={value[1]} />
						})}
					</div>
				</div>
				);
		}
	}
}

class Link extends React.Component {
	render() {
		let link = '/'+this.props.link;
		return (
			<a href={link} >{this.props.label}</a>
			);
	}
}

// Body
class Body extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			page: 0,
			msg: false,
		}
		let $this = this;
		socket.on('toDialog', function(msg) {
			// go to dialog page
			$this.setState({page: 'dialog_page', msg: msg});

		});
	}
	render() {
		// check for page
		if(this.state.page == 'dialog_page') {
			// its dialog page
			return (
				<div className="row">
					<div className="col-3">sidebar</div>
					<DialogPage msg={this.state.msg} />
				</div>
				);
		}
		if(this.props.page == 'dialogPage') {
			// its registration page
			let did = location.href.split('/dialogs/')[1];
			return (
				<div className="row">
					<DialogPage did={did} />
				</div>
				);
		} 
		else if(this.props.page == 'register') {
			// its registration page
			return (
				<div className="row">
					<RegisterMainForm />
				</div>
				);
		} 
		else if (this.props.page == 'login') {
			// its login page
			return (
				<div className="row">
					<LoginMainForm />
				</div>
				);
		}
		else if(this.props.page == 'dialogs') {
			// its dialogs page
			return (
				<div className="row">
					<Dialogs />
				</div>
				);
		}
		else if(this.props.page == 'friends') {
			// its friends page
			return (
				<div className="row">
					<Friends />
				</div>
				);
		}
		else if(this.props.page == 'profile') {
			// its profile page
			return (
				<div className="row">
					<Profile />
				</div>
				);
		}
		else {
			// its main page
			return (
				<div className="jumbotron row">
					<div className="col-8">
					  <MainJumbotron />
					</div>
					<div className="col-4">
						<LoginForm />
						<RegisterForm />
					</div>
				</div>
				);
			
		}
	}
}

// Show dialog page with messages
class DialogPage extends React.Component {
	constructor(props) {
		super(props);
		let $this = this, mprops = this.props.msg, did;
		this.state = {
			users: (mprops) ? mprops.users : false, // users who in dialog
			messages: (mprops) ? mprops.messages : false, // messages
			did: (mprops) ? mprops.did : (this.props.did) ? this.props.did : false, // dialog ID
		};
		$chat.info.did = this.state.did; // remember did
		did = this.state.did;


		if(this.props.did) {
			// user open this dialog
			socket.emit('getDialog', did);
		}
		
		// include socket block
		this.didSocketInclude();
		// check read messages
		this.didReadMessages();

		

	}

	didSocketInclude() {
		// our sockets
		let $this = this; 
		
		// wait dialog info and his messages
		socket.on('getDialog', function(msg) {
			if($this.state.did == msg.did) {
				// check for concurrency
				$this.setState({messages: msg.messages, users: msg.users});
				if($chat.user.isActive) {
					// user is online
					this.didReadMessages(); // read messages
				}
			}
		});

		socket.on('newMessage', function(msg) {
			// get new message
			let did2 = msg.did, message = msg.message;
			if($chat.info.did == did2) {
				// user in this dialog
				let msgs = $this.state.messages;
				if($this.state.messages) {
					// found messages
					msgs.push(message);
				}
				else {
					// not found messages
					msgs = [message];
				}
				$this.setState({messages: msgs}); // add new message to end
				if($chat.user.isActive) {
					// if user is active
					if($username !== message.username) {
						// its not sender this message
						// read message
						socket.emit('readMessage', {mid: message.mid, did: message.did});
					}
				}
			}
		});

		socket.on('readMessage', function(msg) {
			// readed message
			let messages = $this.state.messages;
			messages.map(function(message, index) {
				if(message.mid == msg.mid) {
					// its this message
					messages[index].read_state = 1;
					$this.setState({messages: messages});
				}
			});
		});
	}

	didReadMessages(msg = this.state.messages) {
		// check read messages
		if(msg) {
			// have messages or not
			msg.map(function(message) {
				if(message.read_state == 0) {
					// message not read
					// say to server that user read this message
					socket.emit('readMessage', {mid: message.mid, did: message.did});
				}
			});
		}
	}


	render() {
		let msg = this.state.messages, $this = this; // processing of data message
		if(msg) {
			// have messages
			return (
				<div className="messages_page">
					<div className="messages_page_inner">
						<div className="messages_page__body">
							<ul className="messages__items list-unstyled">
								{msg.map(function(message, index) {
									// get message
									return (<Message key={index} users={$this.state.users} message={message} />);
									
								})}
							
							</ul>
						</div>
						<AddMessageForm />
					</div>
				</div>
			);
		}
		else {
			return (
				<div className="messages_page">
					<div className="messages_page_inner">
						<div className="messages_page__body">
							<div className="noneMessages">
								Сообщений не найдено
							</div>
							<ul className="messages__items list-unstyled">

							</ul>
						</div>
						<AddMessageForm />
					</div>
				</div>

				)
		}

	}
}

// form to add new message
class AddMessageForm extends React.Component {
	constructor(props) {
		super(props);
		this.handleSendMessageClick = this.handleSendMessageClick.bind(this); // user add new message Button Click
		this.handleMessageInput = this.handleMessageInput.bind(this); // user onkey down message input
		this.handleDragOver = this.handleDragOver.bind(this); // catch drag-drop
		this.handleDragLeave = this.handleDragLeave.bind(this);
		// this.handleDrop = this.handleDrop.bind(this);
		this.handleAttachmentMenuOpen = this.handleAttachmentMenuOpen.bind(this); // open menu attachments
		// this.handleAttachmentMenuHide = this.handleAttachmentMenuHide.bind(this); // hide menu attachments
		this.attachPhoto = this.attachPhoto.bind(this); // attach photo, menu item
		this.attachDocument = this.attachDocument.bind(this); // attach document, menu item
		this.handleRemoveAttach = this.handleRemoveAttach.bind(this); // user click on delete attachment


		this.state = {
			id: 'AddMessageForm',
			maxFileSize : 15 * 1000000, // 15 mb max file size
			dropClass: '', // class of drop zone
			isDropClass: '', // available to show dropzone
			alertMessage: false, // alert message to user
			attachments: new Set(), // attach files
			modul: false, // show window
		}

		this.didSocketInclude(this);
	}

	didSocketInclude($this) {
		// include socket waiting..
	

		socket.on('newAttachment', function(msg) {
			// server complete add new file or image
			let a = $this.state.attachments,
    			b = {
        			name: msg.name, 
        			link: '/uploads/' + msg.type + '/' + msg.name,
        			size: msg.size,
        			type: msg.type,
        		};
    		// save this attachment
    		a.add(b);
    		$this.setState({
    			attachments: a
    		});
    		if(!$chat.info.dropfiles.has(b)) {
        		$chat.info.dropfiles.add(b);
    		}
		});
	}

	handleMessageInput(event) {
		// catch key from Message Input
		if(event.keyCode == 13) {
			// user on key down Enter
			let value = $('#message_input').val(), atts = this.state.attachments, attachments = [];
			if(value.length > 0) {
				atts.forEach((attach) => {
					attachments.push(attach);
				})
				socket.emit('addNewMessage', {did: $chat.info.did, body: unHack(value), attachments: attachments});
				$('#message_input').val('').focus();
				atts.clear();
				this.setState({
					attachments: atts,
				});
				$chat.info.dropfiles.clear(); // clear attachments
			}
		}
	}

	handleSendMessageClick(event) {
		// user click on New Message Button
		let value = $('#message_input').val(), atts = this.state.attachments, attachments = [];
		if(value.length > 0) {
			atts.forEach((attach) => {
				attachments.push(attach);
			})
			socket.emit('addNewMessage', {did: $chat.info.did, body: unHack(value), attachments: attachments});
			$('#message_input').val('').focus();
			atts.clear();
			this.setState({
				attachments: atts,
			});
			$chat.info.dropfiles.clear(); // clear attachments
		}
	}

	/** [Drag-n-Drop]
		* Drag and drop files to area and send them to server
	 */
	 componentDidMount() {
		// after render
		let $this = this, dragTimer,
			$dropzone = document.getElementById("dropzone");
		/*$(document).on('dragenter dragstart dragend dragleave dragover drag drop', (e) => {
			e.preventDefault();
		});*/
		if(!this.state.modul) {
			// user not open window
			$(document).on({
				dragover: (e) => {
					// file in window area
					let dt = e.originalEvent.dataTransfer;
					if (dt.types && (dt.types.indexOf ? dt.types.indexOf('Files') != -1 : dt.types.contains('Files'))) {
						$this.setState({
							isDropClass: 'dragstart'
						});
						clearTimeout(dragTimer);
					}
				},
				dragleave: (e) => {
					// file leave window area
					dragTimer = setTimeout(function() {
						$this.setState({
							isDropClass: ''
						})
					}, 25);
					
				}
			});
			
		}

		// listen for file drop zone
	    siofu.listenOnDrop($dropzone);

    	$chat.user.typeFile = 'docs';
    	$chat.user.placeUpload = this;

	}
	handleDragOver(event) {
		// file hover to site
		if(!this.state.modul) {
			// user not open window
			let $e = $(event.target); // drag zone
			this.setState({
				dropClass: 'hover',
			});
			return false;
		}
	}

	handleDragLeave(event) {
		// file not hover to site
		if(!this.state.modul) {
			// user not open window
			let $e = $(event.target); // drag zone
			this.setState({
				dropClass: '',
			});
			return false;
		}
	}
	handleDrop(e) {
		// file drop to zone
		// e.preventDefault();
		
		if(!this.state.modul) {
		
		}
	}
	componentDidUpdate(prevProps, prevState) {
		// after update
		let $this = this;
		if(this.state.alertMessage) {
			// show alert message
			setTimeout(() => {
				$this.setState({alertMessage : false})
			}, 3000);
		}
		if(this.state.modul) {
			// opened new window
			$('#attachPhoto, #attachDocument').on('hide.bs.modal', function (e) {
				// if user close window
				// update
				if($this.state.attachments !== $chat.info.dropfiles) {
					// appear new attachment
					$this.setState({
						attachments: $chat.info.dropfiles,
						dropClass: false,
						isDropClass: false,
						modul: false,
					});
				} else {
					// dont change attachments
					$this.setState({
						dropClass: false,
						isDropClass: false,
						modul: false,
					});

				}
		    	$chat.user.typeFile = 'docs';
		    	$chat.user.placeUpload = $this;
			});
		}
		if(prevState.attachments !== this.state.attachments && this.state.attachments !== []) {
			// changed attachments

		}
	}

	handleAttachmentMenuOpen(e) {
		// user click on menu attachments
		$('#dropdownAttachmentMenu').dropdown('toggle');
	}

	handleRemoveAttach(attach) {
		// user click on remove attachment
		let attachments = this.state.attachments;
		attachments.delete(attach);
		$chat.info.dropfiles.delete(attach);
		this.setState({
			attachments: attachments,
		});
	}

	attachPhoto() {
		// user click on attach photo in menu
		// open window
		let $this = this;
		this.setState({
			modul: 'attachPhoto',
		});

		return false;
	}

	attachDocument() {
		// user click on attach document in menu
		// open window
		let $this = this;
		this.setState({
			modul: 'attachDocument',
		});
		return false;
	}

	render() {
		let $this = this,
			$alert, 
			attachments = this.state.attachments, // array files
			docs = [],  // document attachments
			photos = [], // photo attachments
			dropzoneClass;
		if(this.state.alertMessage) {
			// Show alert window
			$alert = <Alert message="Файл слишком большой!" />;
		}
		if(attachments) {
			// have attachments
			attachments.forEach((attach) => {
				isConsole(attach);
				if(attach.type == 'photos') {
					// its photo
					photos.push(attach);
				}
				else if(attach.type == 'docs') {
					// its document
					docs.push(attach);
				}
			});
			photos = photos.map((attach, i) => {
				// its photo
				return (
						<div className="attachment" key={i} data-name={attach.name} data-link={attach.link}>
							<img className="preview" src={attach.link} alt=""/>
							<div className="ui_thumb_x_button" onClick={() => $this.handleRemoveAttach(attach)} aria-label="Удалить" role="link">
								<div className="ui_thumb_x"></div>
							</div>
						</div>
					)
			})
			docs = docs.map((attach, i) => {
				// its document
				let size = Math.floor(attach.size / 1024); // to Kilobyte
				return (
					 <div className="attachment_doc" key={i} data-name={attach.name} data-link={attach.link}>
						<div className="attachment_doc_row">
						    <a className="attachment_doc_icon attachment_doc_icon1" href={attach.link} target="_blank"></a>
						    <a className="attachment_doc_title" href={attach.link} target="_blank">{attach.name}</a>
						    <div className="attachment_doc_description">
						      <div className="attachment_doc_size">{size} KB</div>
						    </div>
						    <div className="doc_x_button" onClick={() => $this.handleRemoveAttach(attach)} aria-label="Удалить" role="link">
								<div className="doc_x"></div>
							</div>
						  </div>
					</div>
				)
				
			});
		}
		if(!this.state.modul) {
			// window not open
			dropzoneClass = this.state.isDropClass + ' ' + this.state.dropClass;
		}
		return (
			<div className="AddMessageForm">
				{$alert}
				<div id="dropzone" dropzone="copy"
				 onDragOver={this.handleDragOver} 
				 onDragLeave={this.handleDragLeave}
				 className={dropzoneClass} title="drop files for upload">
					<div className="dropdoc">Перетащите файлы сюда,<br /> чтобы прикрепить их к сообщению</div>
				</div>
				<div className="messages_page__input">
					<div className="input__box">
						<div className="dropdown">
						  <button className="btn btn-link" onMouseEnter={this.handleAttachmentMenuOpen}
						  type="button" id="dropdownAttachmentMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						    <span className="more_label"></span>
						  </button>
						  <div className="dropdown-menu" aria-labelledby="dropdownAttachmentMenu">
						    <a className="dropdown-item" href="#photo" onClick={() => this.attachPhoto()}>Фотография</a>
						    <a className="dropdown-item" href="#document" onClick={() => this.attachDocument()}>Документ</a>
						  </div>
						</div>
						<input type="text" className="form-control message_input" id="message_input" name="message_input" onKeyDown={this.handleMessageInput} placeholder="Введите сообщение..." autoFocus="true" />
						<button className="btn btn-outline-primary" onClick={this.handleSendMessageClick}>Отправить</button>
					</div>
					<div className="input__attachments">
						<div className="im_docs">{docs}</div>
						<div className="im_photos">{photos}</div>
						<div className="notes"></div>
					</div>
				</div>
				{this.state.modul &&
					<Modul id={this.state.modul} />
				}
			</div>
		);
	}
}

// Message object
class Message extends React.Component {
	constructor(props) {
		super(props);
		let $this = this;
		this.state = {
			message: this.props.message,
			users: this.props.users,
			user: false,
		};

	}
	componentDidMount() {
		// before render
		let $this = this;
		this.state.users.map(function(user) {
			if(user.username == $this.state.message.username) {
				// find user who add this message
				$this.setState({user: user});
			}
		})
	}
	render() {
		let user = this.state.user, message = this.state.message,
		attachments = message.attachments,
		link = '/users/' + user.username,
		time = moment(message.mdate, 'x').format('HH:mm'),
		name = user.first_name, 
		messageClass = (message.read_state == 0) ? 'messages__item media not_read' : 'messages__item media',
		onlineClass = (user.status == 1) ? 'messages__item__avatar_wrap online' : 'messages__item__avatar_wrap';
		if(attachments.length) {
			// find photo or document
			attachments = attachments.map((item, index) => {
				if(!item) return; 
				return (<Attachment key={index} item={item} />);
			});
		}
		else {
			// not find attachments
			attachments = (<div className="attachments"></div>);
		}
		return (
			<li className={messageClass}>
				<a className={onlineClass} href={link}><img className="messages__item__avatar mr-3" src={user.photo} alt={name} /></a>
					
		    <div className="messages__item__body">
		      <a href={link}><h5 className="mt-0 mb-1">{name} <span className="messages__item__time">{time}</span></h5></a>
		      <div className="media__body">
				{message.body}
				{attachments}
		      </div>
		    </div>
		  </li>
		);
	}
}

class Attachment extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		let $this = this,
			item = this.props.item;
		if(item.type == 'docs') {
			// its document
			// item.size = item.size / 1024; // to KB
			return (
				<div className="media_doc">
					<div className="media_doc_row">
					    <a className="media_doc_icon media_doc_icon1" href={item.link} target="_blank"></a>
					    <a className="media_doc_title" href={item.link} target="_blank">{item.name}</a>
					    <div className="media_doc_description">
					      <div className="media_doc_size">{item.size} KB</div>
					    </div>
					  </div>
				</div>
				)
		}
		else {
			// its photo
			return (
				<div className="media_photo">
					<div className="media_photo_row">
						<img className="media_photo_post" src={item.link} alt=""/>
					</div>
				</div>
				);
		}
		return (
			<div className="attachment">{this.props.item.name}</div>


			);
	}
}

// dialogs page
class Dialogs extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			dialogs: false,
			page: 0, // page 0 - main, page 1 - create dialog
			add_form: 0, // show form: 0 - no, 1 - create dialog, 2 - search messages
			search: $chat.search.info,
		}
		this.handleCreateDialogClick = this.handleCreateDialogClick.bind(this); // on click Create Dialog Button
		this.handleGoToDialogClick = this.handleGoToDialogClick.bind(this); // on click Go To Dialog Button
		this.handleSearchEnter = this.handleSearchEnter.bind(this); // on key down Search Field


		let $this = this;
		// send page = 0 for get dialogs
		socket.emit('getDialogs', 0);
		// listen answer from server
		socket.on('getDialogs', function(msg) {
			// get dialogs
			$this.setState({dialogs: msg});
		});
		socket.on('newDialog', function(msg) {
			// new dialog from server
			$this.setState({dialogs: $this.state.dialogs.push(msg)}); // add to list of dialogs
		});
	}

	handleCreateDialogClick(event) {
		// create dialog
		this.setState({add_form: 1}); // page new dialog
	}

	handleGoToDialogClick(event) {
		// go to dialog
		let search = event.target.value;
		if(/\W/.test(search)) {
			isConsole('its not good');
		} else {
			this.setState({add_form: 0}); // hide create dialog form
			socket.emit('createDialog', search); // send username to server
			this.setState({search: ''});
			$chat.search.info = '';
			$('#search_username').val(''); // clear input text
		}
	}

	handleRemoveClick(sid, username) {
		// remove username
		let usernames = this.state.search, unames = usernames.split(',').slice();
		// $('.search_control__username[data-id="' + sid + '"]').hide();
		if(usernames.indexOf(',') > -1) {
			// have usernames
			let uIndex = unames.findIndex(function(uname){
				if(username == uname) {
					return true;
				}
			});
			unames.splice(uIndex, 1);
			if(unames[0] == '') {
				usernames = '';
			}
			else {
				usernames = unames.join(',');
			}
		}
		else {
			usernames = '';
		}
		
		this.setState({search: usernames});
		
	} 

	handleSearchEnter(event) {
		// onkeyDown search field
		if(event.keyCode == 188 || event.keyCode == 191 || event.keyCode == 13) {
			if(event.target.value.length > 2) {
				let search = event.target.value;
				if(/\W/.test(search)) {
					isConsole('its not good');
				} else {
					this.setState({add_form: 0}); // hide create dialog form
					socket.emit('createDialog', search); // send username to server
					this.setState({search: ''});
					$chat.search.info = '';
					$('#search_username').val(''); // clear input text
				}
			}
			return false;
		}
	}

	render() {
		let $elements, search_form;


		if(this.state.add_form == 0) {
			// if user click on Create Dialog Button
			let $this = this,
				search = this.state.search, 
				countNames = (search.indexOf(',') > -1) ? search.split(',').length : 0,
				sid = -1;

			if(countNames > 1) {
				// array have names example: username1, username2. Count :: 2
				search = search.split(',');
				search = search.map(function(username, index) {
					// process array for usernames
					sid++;
					return (<SearchItem key={index} sid={sid} username={username} onClick={() => $this.handleRemoveClick(sid, username)} />);
				});
			} 
			else if(search.length > 2) {
				// not array. Have only one username
				sid++;
				search =  (<SearchItem sid={sid} username={search} onClick={() => $this.handleRemoveClick(sid, search)} />);
			}
			else {
				search =  '';
			}
			
			search_form = (
				<div className="search_control">
					<div className="search_control__usernames">
					{search}
					</div>
					<input type="text" className="form-control" id="search_username" placeholder="Введите логин друга" onKeyDown={this.handleSearchEnter} />
					<button className="btn-primary btn" id="createDialog" onClick={this.handleGoToDialogClick}>Написать сообщение</button>
				</div>
				);
		} else if(this.state.add_form == 1) {
			search_form = <button className="btn-primary btn" id="createDialog" onClick={this.handleCreateDialogClick}>Создать диалог</button>;
		}

		if(this.state.page == 1) {
			// page new dialog
		}
		else {
			// page main
			if(this.state.dialogs.length > 0) {
				// user have dialogs 
				$elements = (
					<div className="dialogs">
						<div className="dialogs__search">
							{search_form}
							
						</div>
						<div className="dialogs__list">
							<ul className="dialogs__items list-unstyled">
								{this.state.dialogs.map((dialog, index) => {
									return <DialogItem key={index} dialog={dialog} />
								})}
							</ul>
						</div>
					</div>
				);
			}
			else {
				// user dont have dialogs
				$elements = (
					<div className="dialogs">
						<div className="dialogs__nofind">
							<div className="dialogs__nofind_text">
								Начните общаться прямо сейчас.
							</div> 
							{search_form}
						</div>
					</div>
				);
			}
			
		}
		return $elements;
	}
}

// usernames in search form
class SearchItem extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			sid: this.props.sid,
		}

	}

	render() {
		let username = this.props.username;
		// output username(search_item) block
		return (
			<div data-id={this.state.sid} className="search_control__username btn btn-primary">
				<span className="username">{username}</span>
				<span className="remove" onClick={() => this.props.onClick()}>x</span>
			</div>
		);
	}
}

// get dialog item
class DialogItem extends React.Component {
	constructor(props) {
		super(props);
		let $this = this, dialog = this.props.dialog;
		this.handleDialogClick = this.handleDialogClick.bind(this); // user click on dialog
		this.state = {
			value: 0,
			did: dialog.did, // dialog id
			dialog: dialog,
			lastMessage: false,
			users: [], // users photo
			usersName: [], // user names who in dialog
			dialogName: false, // string name of dialog
		};

		socket.emit('getLastMessage', dialog.did);
		// socket.emit('getDialogUsers', {did: dialog.did, usernames: dialog.usernames}); // send to server. get users

		this.didSocketInclude(dialog);
	}

	// who in dialog
	componentDidMount() {
		let $this = this;
		Promise.all(this.state.dialog.usernames.map(function(user){
			// find all and append user info
			let a = $this.state.usersName, b = $this.state.users;
			a.push(user.first_name + ' ' + user.last_name);
			b.push(user);
			$this.setState({usersName: a}); // name users
			$this.setState({users: b}); // photo users
		})).then((users) => {
			$this.setState({dialogName : $this.state.usersName.join(',')});
		});
	}

	/** [didSocketInclude description]
	* Socket box
	* @param dialog [array]
	 */
	didSocketInclude(dialog) {
		// socket box
		let $this = this, did = $this.state.did;
		socket.on('getLastMessage', function(message){
			// get last message from Dialog
			if(message) {
				if(message.did == did) {
					$this.setState({lastMessage: message});
				}
			}
		});

		socket.on('newMessage', function(msg) {
			// get new message
			if(did == msg.did) {
				// if new message for this dialog
				$this.setState({lastMessage: msg.message}); // add new message
			}
		});

		/** [readMessage]
		* User(anyone) read message
		* @param mid Integer [message id] 
		 */
		socket.on('readMessage', function(mid) {
			// anyone read message
			let lMessage = $this.state.lastMessage;
			if(lMessage.mid == mid && did == lMessage.did) {
				// its this message
				lMessage.read_state = 1; // set message is readed
				$this.setState({lastMessage: lMessage});
			}
		});
	}

	handleDialogClick(event) {
		// user click on dialog
		socket.emit('toDialog', this.props.dialog.did); // go to dialog
		// location.href('/dialogs/' + this.state.did);
	}

	render() {
		let $this = this,
			dialog = this.props.dialog, 
			dialogName = this.state.dialogName,
			lastMessage,
			lMessage = this.state.lastMessage, 
			users = this.state.users,
			lMessageReadClass,
			photo;
		if(lMessage || 1 == 1) {
			// have last message
			lMessageReadClass = (lMessage.read_state && lMessage.read_state == 1) ? 'last_message__body' : 'last_message__body not_read'; // read and not read Class
			
			if(dialog.type == 'group') {
				// its one people to group dialog
				if(dialog.name) {
					// set name of dialog
					dialogName = dialog.name;
				}

				if(dialog.photo) {
					// dialog have photo
					photo = (
						<a className="dialogs__item__avatar_wrap" href={link}><img className="dialogs__item__avatar mr-3" src={dialog.photo} alt={name} /></a>
					);
				} 
				else {
					// no photo, show users. Max 4 users
					let countUsers = 0;
					photo = users.map(function(user, index) {
						if(user.username == $username) return;
						
						countUsers += 1;
						if(countUsers < 5) {
							let link = '/users/' + user.username, name = user.first_name + ' ' + user.last_name,
							onlineClass = (user.status == 1) ? 'dialogs__item__avatar_wrap online dia-'+countUsers : 'dialogs__item__avatar_wrap dia-'+countUsers;
							return (
								<a key={index} className={onlineClass} href={link}><img className="dialogs__item__avatar mr-3" src={user.photo} alt={name} /></a>
							);
						}
					});
				}
			
			}
			else {
				// its one people to one type dialog
				photo = users.map(function(user, index) {
					if(user.username == $username) return;
					let link = '/users/' + user.username, name = user.first_name + ' ' + user.last_name,
					onlineClass = (user.status == 1) ? 'dialogs__item__avatar_wrap online dia-1' : 'dialogs__item__avatar_wrap dia-1';
					return (
						<a key={index} className={onlineClass} href={link}><img className="dialogs__item__avatar mr-3" src={user.photo} alt={name} /></a>
					);
				});
				
			}

			users.map(function(user, index) {
				if(user.username == lMessage.username) {
					// if its username who add last Message
					let link = '/users/' + user.username, name = user.first_name;
					lastMessage = (
				      <div key={index} className="media media__last_message">
					        <img className="last_message__avatar mr-3" src={user.photo} />
					      <div className="media-body">
					        <div className={lMessageReadClass}>
					        	{lMessage.body}
					        </div>
					      </div>
				      </div>
						);
					
				}
					
			});
			return (
				<li className="dialogs__item media" onClick={this.handleDialogClick}>
					<div className="dialogs__item__photo">
					    {photo}
					</div>
				    <div className="media-body">
				      <h5 className="mt-0 mb-1">{dialogName}</h5>
						{lastMessage}
					</div>
				</li>
			);
		} else {
			lastMessage = '';
			return (<div className="dialog"></div>);
		}

		
	}
}

// User Page Profile /users/{username}
class Profile extends React.Component {
	constructor(props) {
		super(props);
		let $this = this;
		this.handleSendMessageClick = this.handleSendMessageClick.bind(this); // user click on Send Message Button
		this.handleAddToFriendClick = this.handleAddToFriendClick.bind(this); // user click on Add To Friends Button
		this.handleDeleteFriendClick = this.handleDeleteFriendClick.bind(this); // user click on Delete From Friends Button
		this.handlePhotoUpload = this.handlePhotoUpload.bind(this); // user click on Settings btn
		this.state = {
			id: 'UploadPhoto',
			username: location.href.split('/users/')[1],
			answer: false,
			msg: false,
			isFriend: false,
			modul: false, // modul state if no opened - false
		}
		

		this.willSocketSend(this);
		this.didSocketInclude(this);
	}

	willSocketSend($this) {
		socket.emit('getProfile', $this.state.username); // send username to server
		socket.emit('isFriend', $this.state.username); // this user is friend?
	}

	componentDidUpdate(prevProps, prevState) {
		// after update
		let $this = this;
		$('#uploadPhoto').on('hide.bs.modal', function (e) {
			// if user close window
			// update
			let photo_attach;

			$chat.info.dropfiles.forEach((attach) => {
				photo_attach = attach;
				socket.emit('setAvatar', attach.link);
			});
			$this.setState({
				modul: false,
			});
			isConsole(photo_attach);
		});
		$('#sendMessage').on('hide.bs.modal', function (e) {
			// if user close window
			$this.setState({
				modul: false,
			});
		});
	}

	didSocketInclude($this) {
		// sockets
		socket.on('getProfile', function(msg) {
			// get answer from server
			$this.setState({answer: true, msg: msg}); // tell that we got answer
			// information about recepient user
			$chat.info.recepient.username = msg.username;
			$chat.info.recepient.photo = msg.photo;
			$chat.info.recepient.status = msg.status;
			$chat.info.recepient.last_activity = msg.last_activity;
			$chat.info.recepient.name = msg.first_name + ' ' + msg.last_name;

		});

		socket.on('setAvatar', function(msg) {
			// new avatar
			let user = $this.state.msg;
			user.photo = msg;
			$this.setState({
				msg: user,
			})
			$chat.info.recepient.photo = msg;
		})

		socket.on('isFriend', function(msg) {
			// user is friend?
			if(msg) {
				$this.setState({
					isFriend: msg,
				});
			}
			else {
				$this.setState({
					isFriend: msg,
				})
			}
		})

	}

	handleSendMessageClick(event) {
		// user click on Send Message Button
		this.setState({
			modul: 'sendMessage'
		});
	}

	handleAddToFriendClick(event) {
		// user click on Add To Friends Button
		socket.emit('addToFriend', this.state.msg.username);
	}

	handleDeleteFriendClick(event) {
		// user click on Add To Friends Button
		socket.emit('deleteFriend', this.state.msg.username);
	}

	handlePhotoUpload(event) {
		// user click on upload photo
		// open window
		let $this = this;
		this.setState({
			modul: 'uploadPhoto',
		});

		return false;
	}

	render() {
		let msg = this.state.msg, status = (msg.status == 1) ? 'online' : (msg.last_activity) ? 'last seen ' + msg.last_activity : 'offline',
			$btnFriend, $sendMessage;

		if(this.state.isFriend) {
			// user is friend
			$btnFriend = (
				<button type="button" onClick={this.handleDeleteFriendClick} className="btn btn-outline-primary">Убрать из друзей</button>
				);
		}
		else {
			// user is not friend
			$btnFriend = (
				<button type="button" onClick={this.handleAddToFriendClick} className="btn btn-outline-primary">Добавить в друзья</button>
				);
		}
		$sendMessage = (
			<button type="button" onClick={this.handleSendMessageClick} className="btn btn-primary">Написать сообщение</button>
			);
		if($username == msg.username) {
			// its my account page
			$btnFriend = false;
			$sendMessage = (
				<button type="button" onClick={this.handlePhotoUpload} className="btn btn-primary">Загрузить фото</button>
				);
		}
		if(this.state.answer) {
			// data is defined
			return (
					<div className="row profile_page">
						<div className="col-3">
							<img src={msg.photo} className="profile_page__avatar" alt=""/>
							<div className="profile_page__buttons">
								{$sendMessage}
								{$btnFriend}
							</div>
						</div>
						<div className="col-9">
							<h2 className="page_name">{msg.first_name} {msg.last_name} <span className="profile_status">{status}</span></h2>
							<div className="profile_page__info">
								Здесь кратко о пользователе..
								{this.state.modul &&
									<Modul id={this.state.modul} />
								}
							</div>

						</div>
					</div>
				);
		} else {
			return 'Не найден пользователь';
		}
	}
}


// Friends list
class Friends extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			friends: false,
			page: 0,
		}

		this.willSocketSend(this);
		this.didSocketInclude(this);
	}

	willSocketSend($this) {
		// before
		socket.emit('getFriends', $this.state.page);
	}

	didSocketInclude($this) {
		// wait answer from server
		socket.on('getFriends', (msg) => {
			$this.setState({
				friends: msg,
			})
		})
	}

	render() {
		let $this = this,
			$elements,
			search_form,
			$friends = $this.state.friends;

		if($friends.length > 0) {
			$elements = (
				<div className="friends">
					<div className="friends__search">
						{search_form}
						
					</div>
					<div className="friends__list">
						<ul className="friends__items list-unstyled">
							{$friends.map((friend, index) => {
								return <FriendItem key={index} friend={friend} />
							})}
						</ul>
					</div>
				</div>
				);
			
		} else {
			$elements = (
				<div className="friends">
					<div className="friends__search">
						{search_form}
						
					</div>
					<div className="friends__list">
						<ul className="friends__items list-unstyled">
							<div className="friends__nofind">
								<div className="friends__nofind_text">
									Вы еще не добавили ни одного друга
								</div>
							</div>
						</ul>
					</div>
				</div>
				);
		}

		return $elements;

	}
}

class FriendItem extends React.Component {
	constructor(props) {
		super(props);

		this.handlefriendClick = this.handlefriendClick.bind(this);

		this.state = {
			friend: this.props.friend,
		}
	}

	handlefriendClick(event) {
		// user click on friend
	}

	render() {
		let friend = this.state.friend,
			$friend = friend.friend,
			$user = friend.user,
			photo,
			friend_list = ['', 'Лучший друг'],
			status = ($user.status == 1) ? 'online' : ($user.last_activity) ? 'last seen ' + $user.last_activity : 'offline',
			link = '/users/' + $user.username, name = $user.first_name + ' ' + $user.last_name,
			onlineClass = ($user.status == 1) ? 'dialogs__item__avatar_wrap online dia-1' : 'dialogs__item__avatar_wrap dia-1';
		
		photo = (
			<a key={index} className={onlineClass} href={link}><img className="dialogs__item__avatar mr-3" src={$user.photo} /></a>
		);

		return (
			<li className="friends__item media" data-type={$friend.type}>
					<div className="friends__item__photo">
					 	{photo}
					</div>
				    <div className="media-body">
				      <h5 className="mt-0 mb-1">
				      	<a href={link}>
				      		{$user.first_name} {$user.last_name}
			      		</a>
				      </h5>
						
					</div>
				</li>
			)
	}
}

// Call to action
class MainJumbotron extends React.Component {
	render() {
		return (
			<div className="mainjumbotron">
				<h1 className="display-4">Привет, друг!</h1>
				 <p className="lead">Это простой чат, где нет ничего лишнего.</p>
				 <hr className="my-4" />
				 <p>Почувствуй больше, общайся.</p>
				 <p className="lead">
				   <a className="btn btn-primary btn-lg" href="/users/register" role="button">Начать пользоваться</a>
				 </p>
			</div>
			);
	}
}

// LoginForm on start page
class LoginForm extends React.Component {
	render() {
		return (
			<div className="loginform">
				<form action="/users/login" method="post">
				  <div className="form-group">
				    <input type="text" className="form-control" id="username" name="username" placeholder="Введите логин" autoFocus="true" required />
				  </div>
				  <div className="form-group">
				    <input type="password" className="form-control" id="password" name="password" placeholder="Пароль" required />
				  </div>
				  <div className="loginform__buttons">
					  <button type="submit" className="btn btn-primary">Войти</button><a href="/users/register" className="btn btn-outline-primary" role="button">Зарегестрироваться</a>
				  </div>
				</form>
			</div>
			);
	}
}
// RegisterForm
class RegisterForm extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			''
			);
	}
}

// LoginMainForm on LoginPage
class LoginMainForm extends React.Component {
	render() {
		return (
			<div className="loginmainform">
				<form action="/users/login" method="post">
				  <div className="form-group">
				    <input type="text" className="form-control" id="username" name="username" placeholder="Введите логин" autoFocus="true" required />
				  </div>
				  <div className="form-group">
				    <input type="password" className="form-control" id="password" name="password" placeholder="Пароль" required />
				  </div>
				  <div className="loginform__buttons">
					<button type="submit" className="btn btn-primary">Войти</button>
				  </div>
				</form>
			</div>
			);
	}
}
// RegisterMainForm
class RegisterMainForm extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			value: 0,
			btnText: ['Регистрация', 'Получить письмо', 'Начать пользоваться'],
			alert: false,
		};
	}
	render() {
		// main step
		return (
			<div className="registermainform">
					<RegisterControl step={this.state.value} />
			</div>
			);
		
			
		
	}
}
// register controller for steps
class RegisterControl extends React.Component {
	constructor(props) {
		super(props);
		this.handleContinueClick = this.handleContinueClick.bind(this);
		this.handleFinishClick = this.handleFinishClick.bind(this);
		this.state = {
			step: this.props.step,
			nameStep: ['Регистрация','Проверка'],
			nameBtn: ['Продолжить','Регистрация'],
		};
	}

	handleContinueClick(event) {
		// user click on continue button
		let $this = this;
		if(this.state.step == 0) {
			if($('#reg_first_name').isValid({}) && $('#reg_last_name').isValid() && $('#reg_date').isValid()) {
				this.setState({step: this.state.step+1});
			}
		} 

		event.preventDefault();
		return false;
	}

	handleFinishClick(event) {
		// user click on end registration button
		event.preventDefault();
		this.setState({step: this.state.step+1});
	}

	render() {
		let step = this.state.step, elements = null,
		 stepMainClass = (step == 0) ? 'register_steps__main' : 'register_steps__main none',
		 stepValidClass = (step == 1) ? 'register_steps__continue none' : 'register_steps__continue',
		 btnSubmit;
		 if(step == 0) {
		 	btnSubmit = this.handleContinueClick;
		 	stepMainClass = 'register_steps__main';
		 	stepValidClass = 'register_steps__continue none';
		 } else if(step == 1) {
		 	btnSubmit = false;
			stepMainClass = 'register_steps__main none';
		 	stepValidClass = 'register_steps__continue';
		 }


			elements = (
				<form action="/users/register" method="post" className="form-inline" onSubmit={btnSubmit} >
					<div className={stepMainClass}>
					<h4>{this.state.nameStep[step]}</h4>
						<div className="form-group">
						  <input type="text" className="form-control" name="first_name" id="reg_first_name" placeholder="Имя" autoFocus="true" required />
						</div>
						<div className="form-group">
						  <input type="text" className="form-control" name="last_name" id="reg_last_name" placeholder="Фамилия" required />
						</div>
						<div className="form-group">
						  <input type="date" className="form-control" name="date" id="reg_date" min="1940-01-01" max="2012-12-12" required />
						</div>
					</div>
					<div className={stepValidClass}>
						<div className="form-group">
						  <input type="email" className="form-control" name="email" id="reg_email" placeholder="Email" />
						</div>
						<div className="form-group">
						  <input type="text" className="form-control" name="username" id="reg_username" placeholder="Логин" />
						</div>
						<div className="form-group">
						  <input type="password" className="form-control" name="password" id="reg_password" placeholder="Пароль" />
						</div>
					</div>
					<button type="submit" className="btn btn-primary">{this.state.nameBtn[step]}</button>
				</form>
			);
		
		if(step == 2)  {
			// successful information for user
			elements = (
				<div className="register_step__finish">
					<h4>Спасибо за регистрацию.</h4>
					<p className="lead">Подтвердите письмо и вы получите все возможности чата.</p>
				</div>
				);
		}
		return elements;

	}
}

/** [Modul]
	* Windows on the site(new Message, Friend ..)
	* Functions: Create, show, close
 */
class Modul extends React.Component {
	constructor(props) {
		super(props);
		let $this = this, id = this.props.id;
		// handle methods
		this.handleCtrlEnter = this.handleCtrlEnter.bind(this); // ctrl+enter on Message Input
		this.handleCheckLen = this.handleCheckLen.bind(this); // Check len onKeyUp
		this.handleChange = this.handleChange.bind(this); // Input Text Box onChange
		this.handleSendMessage = this.handleSendMessage.bind(this); // Send message to server
		this.handleDragOver = this.handleDragOver.bind(this); // catch drag-drop
		this.handleDragLeave = this.handleDragLeave.bind(this); // file leave dropzone
		this.handleDrop = this.handleDrop.bind(this); // file drop in dropzone
		this.handleUpload = this.handleUpload.bind(this); // button Upload
		this.handleSelectAttach = this.handleSelectAttach.bind(this); // user click on photo or document
		this.handleSelectPhoto = this.handleSelectPhoto.bind(this); // user click on photo
		this.handleSelectAttachments = this.handleSelectAttachments.bind(this); // user click on attachment and select him

		this.state = {
			id: this.props.id, // no opened Windows
			closeWindow: false, // in true window close(act)
			isClosedWindow: false, // window is closed(state)
			alertMessage: false, // alert message on page
			value: false, // text of message
			dropClass: false, // dropclass of file
			isDropClass: false, // available to show dropzone
			maxFileSize : 15 * 1000000, // 15 mb max file size
			attachments: new Set(), // attachments
		};

		this.willSocketSend($this, id);
		this.didSocketInclude($this);
		isConsole(id);

	}

	/** [willSocketSend]
		* Send socket commands to server
		* @param {$this} [Object]
		* @param {id} [String]
	 */
	willSocketSend($this, id) {
		if(id == 'attachDocument') {
			socket.emit('getUserDocuments', '');
		}
		else if(id == 'attachPhoto' || id == 'uploadPhoto') {
			socket.emit('getUserPhotos', '');
		}
	}

	/** [didSocketInclude]
		* Add socket functions to Modul, listen server
		* @param {$this} [Object]
	 */
	didSocketInclude($this) {
		/** [sendMessageToUser]
			* If user create message
			* @param {String} [msg]
		 */
		socket.on('sendMessageToUser', function(msg) {
			if(msg == 'successful') {
				$this.setState({alertMessage: true}); // open alert window
			}
		});
		/** [getUserDocuments]
			* Get documents which user have
			* @param {Array} [docs]
		 */
		socket.on('getUserDocuments', function(docs) {
			isConsole(docs);
			let attachments = $this.state.attachments, atts = new Set();
			attachments.clear();
			docs.map((item) => {
				item.select = false;
				atts.add(item);
			});
			// insert documents in attachments
			$this.setState({
				attachments: atts,
			});
		});
		/** [getUserPhotos]
			* Get photos which user have
			* @param {Array} [photos]
		 */
		socket.on('getUserPhotos', function(photos) {
			let attachments = $this.state.attachments, atts = new Set();
			attachments.clear();
			photos.map((item) => {
				item.select = false;
				atts.add(item);
			});
			isConsole(photos);
			// insert photos in attachments
			$this.setState({
				attachments: atts,
			});
		});

		socket.on('newAttachment', function(msg) {
			// server complete add new file or image
			let a = $this.state.attachments,
    			b = {
        			name: msg.name, 
        			link: '/uploads/' + msg.type + '/' + msg.name,
        			size: msg.size,
        			type: msg.type,
        		};

    		if(!$chat.info.dropfiles.has(b)) {
        		$chat.info.dropfiles.add(b);
    		}
    		// save this attachment
    		a.add(b);
    		$this.setState({
    			attachments: a
    		});
		});
	}

	/** [handleOpenModul]
		* Open window
		* @param {id} [String]
	 */
	handleOpenModul(id) {
		if(!$('#' + id).length) {
			// not exist
			return;
		}
		// this.setState({closeWindow: false, alertMessage: false});
		$('#' + id).modal('show');
	}

	/** [handleCloseModul]
		* Close window by id
		* @id - string
	 */
	handleCloseModul(id) {
		$('#' + id).modal('hide');
	}

	/** [handleCtrlEnter]
		* ctrl+enter on message box event
	 */
	handleCtrlEnter(event) {
		if((event.ctrlKey) && ((event.keyCode == 0xA)||(event.keyCode == 0xD))) {
			this.SendMessage();
		}
	}

	/** [handleCheckLen]
		* check lenght of text in message input
	 */
	handleCheckLen(event) {
		let value = $(event.target).text();
		this.setState({value: value});

		if(value.length > 1000) {
			$('.warn').text('У вас слишком длинное сообщение')
		}
		else {
			$('.warn').text('')
		}
	}

	/** [handleChange]
		** When user change Text Box of message, function add to state variable
		*@param event
	 */
	handleChange(event) {
		this.setState({value: $(event.target).text()});
	} 

	/** [handleChange]
		** When user click on "Send" Button
		*@param event
	 */
	handleSendMessage(event) {
		this.SendMessage();
	}
	/** [SendMessage]
		* Send Message to Server Post-request
		* @param array of {username : String, body : String}
		* @username [Name of recepient]
		* @body [Text of message]
	 */
	SendMessage() {
		socket.emit('sendMessageToUser', {username: $chat.info.recepient.username, body: this.state.value});
		this.setState({closeWindow: true}); // close window

	}

	componentDidUpdate(prevProps, prevState) {
		// after update
		if(!prevState.closeWindow && this.state.closeWindow) {
			// if before window opened and now window is closed
			this.handleCloseModul(this.props.id); // close window
		}
		else if(prevState.closeWindow && !this.state.closeWindow) {
			// if before window closed and now window is open
			this.handleOpenModul(this.props.id); // open window by id
		}
		if(!prevState.alertMessage && this.state.alertMessage) {
			// show alert message
			setTimeout(() => {
				this.setState({alertMessage : false})
			}, 3000);
		}
		if(prevState.attachments !== this.state.attachments) {
			// changed attachments
		}
	}

	/** [Drag-n-Drop]
		* Drag and drop files to area and send them to server
	 */
	componentDidMount() {
		// after render
		let $this = this, dragTimer,
			$dropzone = document.getElementById("modal_dropzone"),
			$dropzone1 = document.getElementById("modal_dropzone1"),
			$dropzone2 = document.getElementById("modal_dropzone2");
		$('#' + this.props.id).on('hide.bs.modal', function(e) {
			// hide window
			if(!$this.state.isClosedWindow) {
				$this.setState({isClosedWindow: true});
			}
		});
		this.handleOpenModul(this.props.id); // open window by id
		/*$(document).on('dragenter dragstart dragend dragleave dragover drag drop', (e) => {
			e.preventDefault();
		});*/
		$(document).on({
			dragover: (e) => {
				// window is open
				if(!this.state.isClosedWindow) {
					// file in window area
					let dt = e.originalEvent.dataTransfer;
					if (dt.types && (dt.types.indexOf ? dt.types.indexOf('Files') != -1 : dt.types.contains('Files'))) {
						$this.setState({
							isDropClass: 'dragstart'
						});
						clearTimeout(dragTimer);
					}
				}
			},
			dragleave: (e) => {
				// window is open
				if(!this.state.isClosedWindow) {
					// file leave window area
					dragTimer = setTimeout(function() {
						$this.setState({
							isDropClass: ''
						})
					}, 25);
				}
			}
		});
			
		// listen for file drop zone

		let id = $this.state.id;
    	if(id == 'attachDocument') {
    		// its window with upload document
		    siofu.listenOnDrop($dropzone1);
	    	$chat.user.typeFile = 'docs';
	    	$chat.user.placeUpload = this;
		}
		else if(id == 'attachPhoto') {
			// its window with upload photo
		    siofu.listenOnDrop($dropzone);
	    	$chat.user.typeFile = 'photos';
	    	$chat.user.placeUpload = this;
		}
		else if(id == 'uploadPhoto') {
			// its window with upload photo
		    siofu.listenOnDrop($dropzone2);
	    	$chat.user.typeFile = 'photos';
	    	$chat.user.placeUpload = this;
		}
		
	}

	handleDragOver(event) {
		// file hover to site
		if(!this.state.isClosedWindow) {
			// window is open
			let $e = $(event.target); // drag zone
			this.setState({
				dropClass: 'hover',
			});
			return false;
		}
	}

	handleDragLeave(event) {
		// file not hover to site
		if(!this.state.isClosedWindow) {
			// window is open
			let $e = $(event.target); // drag zone
			this.setState({
				dropClass: '',
			});
			return false;
		}
	}
	handleDrop(e) {
		// file drop to zone. onChange event
		// e.preventDefault();
		
		if(!this.state.isClosedWindow) {
			// window is open

		}
	}

	handleUpload(e) {
		// user click on btn upload
		$('#attach_filezone').trigger('click');
	}

	handleSelectAttachments() {
		// user click on Select attachments
		// close window
		this.setState({
			closeWindow: true,
		})
	}
	handleSelectAttach(attach) {
		let $this = this,
			attachments = this.state.attachments;
		if(attach.select) {
			// if user already select, delete
			if(attachments.has(attach)) {
				attachments.delete(attach);
			}
			if($chat.info.dropfiles.has(attach)) {
				$chat.info.dropfiles.delete(attach);
			}
			attach.select = false;
			if(!attachments.has(attach)) {
				attachments.add(attach);
			}
		}
		else {
			// user still dont select this attach, select
			if(attachments.has(attach)) {
				attachments.delete(attach);
			}
			if(!$chat.info.dropfiles.has(attach)) {
				$chat.info.dropfiles.add(attach);
			}
			attach.select = true;
			if(!attachments.has(attach)) {
				attachments.add(attach);
			}

		}
		$this.setState({
			attachments: attachments,
		})
	}

	handleSelectPhoto(attach) {
		let $this = this,
			attachments = this.state.attachments;
		if(attachments.has(attach)) {
			attachments.delete(attach);
		}
		if(!$chat.info.dropfiles.has(attach)) {
			$chat.info.dropfiles.add(attach);
		}
		attach.select = true;
		if(!attachments.has(attach)) {
			attachments.add(attach);
		}
		$this.setState({
			attachments: attachments,
			closeWindow: true,
		})
	}

	render() {
		let $this = this,
			id = this.props.id,
			$alert,
			value = this.state.value,
			$sendMessage,
			$uploadPhoto,
			$attachPhoto,
			$attachDocument,
			listPhotos = [], // attach photos
			listPhotos2 = [], // upload photo`
			listDocs = [], // attach documents
			$recepient = $chat.info.recepient,
			recepient_status = ($recepient) ? $recepient.status : false;


		if(recepient_status) {
			recepient_status = (recepient_status == 1) ? 'online' : 'last seen ' + $recepient.last_activity + ' offline';
		}
		if(this.state.alertMessage) {
			// Show alert window
			$alert = <Alert message="Успешная отправка сообщения" />;
		}
		
		// set moduls
		// window send message
		if(this.state.isClosedWindow) {
			// window is closed
			return (
				<div className="modalCenter"></div>
				);
		}
		// get list of attachments
		this.state.attachments.forEach((attach) => {
			if(attach.type == 'photos') {
				// its photo
				listPhotos.push(attach);
				listPhotos2.push(attach);
			}
			else if(attach.type == 'docs') {
				// its document
				listDocs.push(attach);
			}
		});
		// photos of user
		listPhotos = listPhotos.map((attach, i) => {
			// its photo
			let classSelected = (attach.select) ? 'selected' : '';
			return (
					<div className={'photoItem ' + classSelected} key={i} onClick={() => $this.handleSelectAttach(attach)} data-name={attach.name} data-link={attach.link}>
						<img className="preview" src={attach.link} alt=""/>
						
					</div>
			)
		});
		// photos of user
		listPhotos2 = listPhotos2.map((attach, i) => {
			// its photo
			let classSelected = (attach.select) ? 'selected' : '';
			return (
					<div className={'photoItem ' + classSelected} key={i} onClick={() => $this.handleSelectPhoto(attach)} data-name={attach.name} data-link={attach.link}>
						<img className="preview" src={attach.link} alt=""/>
						
					</div>
			)
		});
		// documents of user
		listDocs = listDocs.map((attach, i) => {
			// its document
			let size = Math.floor(attach.size / 1024), // to Kilobyte
				classSelected = (attach.select) ? 'selected' : '',
				selectText = (attach.select) ? 'Выбрано' : 'Выбрать';
			return (
				 <div className={'documentItem ' + classSelected} onClick={() => $this.handleSelectAttach(attach)} key={i}>
					<div className="attachment_doc_row">
					    <a className="attachment_doc_icon attachment_doc_icon1" href={attach.link} target="_blank"></a>
					    <a className="attachment_doc_title" href={attach.link} target="_blank">{attach.name}</a>
					    <div className="attachment_doc_description">
					      <div className="attachment_doc_size">{size} KB</div>
					    </div>
					    <div className="doc_select_button" role="link">
							{selectText}
						</div>
					  </div>
				</div>
			)
		});

		if(this.state.attachments.length < 1) {
			// not have attachments
			listPhotos = (<div className="no_photo">У вас нету фотографий</div>);
			listDocs = (<div className="no_docs">У вас нету документов</div>)
		}

		$sendMessage = (<div className="modal fade" id="sendMessage" tabIndex="-1" role="dialog" aria-labelledby="modalCenterTitle" aria-hidden="true">
				 	<div className="modal-dialog modal-dialog-centered" role="document">
					    <div className="modal-content">
					      <div className="modal-header">
					        <h5 className="modal-title" id="exampleModalLongTitle">Новое сообщение</h5>
					        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div className="modal-body">
					      	<div className="mail_recepient_info">
					      		<div className="media media__recepient">
							        <img className="recepient__avatar mr-3" src={$recepient.photo} />
							      <div className="media-body recepient__body">
							        	<div className="recepient__body_name">{$recepient.name}</div>
							        	<div className="recepient__body_status">{recepient_status}</div>
							      </div>
						      </div>
					      	</div>
					      	<div className="mail_box">
					      		<div contentEditable="true" id="mail_box_editable" onChange={$this.handleChange} onKeyUp={$this.handleCheckLen} onKeyPress={$this.handleCtrlEnter}></div>
					      	</div>
					      	<div className="warn"></div>
					      </div>
					      <div className="modal-footer">
					        <button type="button" className="btn btn-primary" onClick={$this.handleSendMessage}>Отправить</button>
					      </div>
					    </div>
					</div>
				</div>);
		$uploadPhoto = (<div className="modal fade" id="uploadPhoto" tabIndex="-1" role="dialog" aria-labelledby="modalCenterTitle" aria-hidden="true">
				 	<div className="modal-dialog modal-dialog-centered modal-lg" role="document">
					    <div className="modal-content">
					      <div className="modal-header">
					        <h5 className="modal-title" id="exampleModalLongTitle">Выбрать фотографию</h5>
					        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div className="modal-body">
					      	<div id="modal_dropzone2" dropzone="copy"
					      	 className={this.state.isDropClass + ' ' + this.state.dropClass}
						 onDragOver={() => this.handleDragOver(event)}  title="drop files for upload"
						 onDragLeave={() => this.handleDragLeave(event)}>
								<button type="button" onClick={this.handleUpload} className="btn btn-primary btn-lg btn-block attach_upload">Загрузить фотографию</button>
					      		<div className="modal_dropzone_title">
					      			Перетащите файлы сюда,<br /> чтобы прикрепить их к сообщению
				      			</div>
					      		<div className="modal_dropzone_photos">
					      			{listPhotos2}
					      		</div>
					      		
					      	</div>
					      	<div className="warn"></div>
					      </div>
					    </div>
					</div>
				</div>);
		$attachPhoto = (<div className="modal fade" id="attachPhoto" tabIndex="-1" role="dialog" aria-labelledby="modalCenterTitle" aria-hidden="true">
				 	<div className="modal-dialog modal-dialog-centered modal-lg" role="document">
					    <div className="modal-content">
					      <div className="modal-header">
					        <h5 className="modal-title" id="exampleModalLongTitle">Выбрать фотографию</h5>
					        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div className="modal-body">
					      	<div id="modal_dropzone" dropzone="copy"
					      	 className={this.state.isDropClass + ' ' + this.state.dropClass}
						 onDragOver={() => this.handleDragOver(event)}  title="drop files for upload"
						 onDragLeave={() => this.handleDragLeave(event)}>
								<button type="button" onClick={this.handleUpload} className="btn btn-primary btn-lg btn-block attach_upload">Загрузить фотографию</button>
					      		<div className="modal_dropzone_title">
					      			Перетащите файлы сюда,<br /> чтобы прикрепить их к сообщению
				      			</div>
					      		<div className="modal_dropzone_photos">
					      			{listPhotos}
					      		</div>
					      		
					      	</div>
					      	<div className="warn"></div>
					      </div>
					      <div className="modal-footer">
					        <button type="button" className="btn btn-primary" onClick={$this.handleSelectAttachments}>Выбрать</button>
					      </div>
					    </div>
					</div>
				</div>);
		$attachDocument = (<div className="modal fade" id="attachDocument" tabIndex="-1" role="dialog" aria-labelledby="modalCenterTitle" aria-hidden="true">
				 	<div className="modal-dialog modal-dialog-centered modal-lg" role="document">
					    <div className="modal-content">
					      <div className="modal-header">
					        <h5 className="modal-title" id="exampleModalLongTitle">Выбрать документ</h5>
					        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div className="modal-body">
					      	<div id="modal_dropzone1" dropzone="copy"
					      	 className={this.state.isDropClass + ' ' + this.state.dropClass}
						 onDragOver={() => this.handleDragOver(event)}  title="drop files for upload"
						 onDragLeave={() => this.handleDragLeave(event)}>
								<button type="button" onClick={this.handleUpload} className="btn btn-primary btn-lg btn-block attach_upload">Загрузить документ</button>
					      		<div className="modal_dropzone_title">
					      			Перетащите файлы сюда,<br /> чтобы прикрепить их к сообщению
				      			</div>
					      		<div className="modal_dropzone_documents">
					      			{listDocs}
					      		</div>
					      		
					      	</div>
					      	<div className="warn"></div>
					      </div>
					      <div className="modal-footer">
					        <button type="button" className="btn btn-primary" onClick={$this.handleSelectAttachments}>Выбрать</button>
					      </div>
					    </div>
					</div>
				</div>);
		// show window
		if(id !== 'sendMessage') {
			$sendMessage = '';
		}
		else if(id !== 'attachPhoto') {
			$attachPhoto = '';
		}
		else if(id !== 'attachDocument') {
			$attachDocument = '';
		}
		else if(id !== 'uploadPhoto') {
			$uploadPhoto = '';
		}
		return (
			<div className="modalCenter">
				{$alert}
				{$sendMessage}
				{$uploadPhoto}
				{$attachPhoto}
				{$attachDocument}
			</div>
		);
	
		// window add to friend
		// window attachments
		
		

	}
}

/** [Alert]
	* Show alert box on site
 */
class Alert extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			message: this.props.message
		}
	}

	render() {
		let $this = this,
			msg = this.state.message; // message on alert box
		if(msg) {
			return (
				<div className="alert alert-success" role="alert">
				  {msg}
				</div>
			);
		}
		return '';
	}
}

/** @type {$chat.user}
	* Keep track of current user, and set his Activity 
 */
$chat.user = {
	mousePosition: {x: 0, y: 0},
	isActive: false,
	timer: false,
	timeNoActive: 0,
	typeFile: 'docs', // type of upload file
	placeUpload: false, // place of dropzone
	state: function() {
		// user on site?
		$(document).bind('mousemove', function(event) {
			let nPosition = {x: event.clientX, y: event.clientY};
			if($chat.user.mousePosition.x == nPosition.x && $chat.user.mousePosition.y == nPosition.y) {
				// user deactive
				$chat.user.timer = setTimeout(function() {
					$chat.user.timeNoActive += 100;
				}, 100);
				if($chat.user.timeNoActive > 15 * 1000) {
					// if user no active on 15 seconds
					$chat.user.isActive = false;
				}
			}
			else {
				$chat.user.isActive = true;
				$chat.user.timeNoActive = 0;
				clearTimeout($chat.user.timer);
			}
		});
	},
	upload: () => {
		// upload listener in dropzone area
		let $this = $chat.user;
		siofu.addEventListener('start', (event) => {
	    	event.file.meta.type = $chat.user.typeFile;
	    	// event.file.name = 'sdfsdf0';
	    });
	 
	    // Do something on upload progress: 
	    siofu.addEventListener("progress", function(event){
	        var percent = event.bytesLoaded / event.file.size * 100;
	        console.log("File is", percent.toFixed(2), "percent loaded");
	    });
	 
	 	siofu.addEventListener("error", function(data){
		    if (data.code === 1) {
		        alert("Don't upload such a big file");
		    }
		});

	    // Do something when a file is uploaded: 
	    siofu.addEventListener("complete", function(event){
	        // console.log(event.detail.file);

	        socket.emit('saveAttachment', event.detail.file);
	        socket.emit('setAvatar', event.detail.file.link);
	        let id = $this.placeUpload.state.id;
	        if(id == 'attachPhoto' || id == 'attachDocument' || id == 'uploadPhoto') {
	        	// its window of photo or document upload
	        	$this.placeUpload.setState({
		        	closeWindow: true,
		        	isDropClass: false,
		        	dropClass: false,
	        	}); // close window

	        } else if(id == 'AddMessageForm') {
	        	$this.setState({
					dropClass: false,
					isDropClass: false,
				});
	        }
	    });
	}
}



// check form validation
$.fn.extend({
	valid: function(a = {min: 2}){
		let $this = this;
		if(this.isValid(a)) {
			this.removeClass('invalid')
		} else {
			this.addClass('invalid')
		}
		if(this.attr('data-check') !== "true") {
			// if input dont have bind on self
			this.attr('data-check', 'true');
			this.bind('keydown', function(e){
				// listen key from input
				if($this.isValid(a)) {
					$this.removeClass('invalid')
				} else {
					$this.addClass('invalid')
				}
			});
		}
	},
	isValid: function(a = {min: 2}) {
		// check {min: (min length), max: (max length)}
		let b = this.val(), re = /[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;
		if(a.email) {
			// this is email
			if(b !== '' && re.test(b)) {
				return true;
			} else {
				return false
			}
		} else {
			if(a.min > b.length) {
				return false
			} else {
				return true
			}
		}
	}
});

// against hackers
function unHack(a) {
	return a.trim();
} 

// user drag-n-drop file to site
Drop = {
	isDropClass: false, // available to drop class
	dragTimer: false, // timer of drag out
	handle() {
		// check file in site area and give him available if true
		let $this = this;
		$(document).on({
			dragover: (e) => {
				// file in window area
				let dt = e.originalEvent.dataTransfer;
				if (dt.types && (dt.types.indexOf ? dt.types.indexOf('Files') != -1 : dt.types.contains('Files'))) {
					$this.isDropClass = 'dragstart';
					clearTimeout(Drop.dragTimer);
				}
			},
			dragleave: (e) => {
				// file leave window area
				Drop.dragTimer = setTimeout(function() {
					$this.isDropClass = '';
				}, 25);
				
			}
		});
	}
}



// render pages
$(document).ready(function(){
	// check for page
	let $dom, $el;
	if(document.getElementById('main')) {
		// its main page
		$el = 'main';
	}
	else if(document.getElementById('login')) {
		// its login page
		$el = 'login';
	}
	else if(document.getElementById('register')) {
		// its register page
		$el = 'register';
	}
	else if(document.getElementById('dialogs')) {
		// its dialogs page
		$el = 'dialogs';
	}
	else if(document.getElementById('friends')) {
		// its friends page
		$el = 'friends';
	}
	else if(document.getElementById('profile')) {
		// its profile page
		$el = 'profile';
	}
	else if(document.getElementById('dialogPage')) {
		// its dialogPage page
		$el = 'dialogPage';
	}
	if($('#'+$el).hasClass('profile')) {
		// user logged in
		isLogged = true;
	}

	$dom = <Container page={$el} />;

	// show the block
	ReactDOM.render(
		$dom,
		document.getElementById($el)
	);
});


/** [isConsole]
	* Output text in console
	* @a typeof number [Its Number of test]
	* @a typeof string [Its just string what are you want to say] 
	* @a is false [Output is test]
 */
function isConsole(a = 'test') {
	if(typeof a === 'number') {
		isConsole('Thats good #' + a)
	}
	else {
		console.log(a)
	}
}