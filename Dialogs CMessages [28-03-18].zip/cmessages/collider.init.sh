#!/bin/sh


USER=collider


case $1 in
        *)
                echo Uknown Action: $1
        ;;
esac
